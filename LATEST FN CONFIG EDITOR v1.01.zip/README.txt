Install Note: You should probably put the zip file and everything in c:/users/(yourname)/appdata/local/fortnitegame/saved/gameusersettings.ini so everytime you select gameusersettings you don't have to go all the way back.
You should get WinRar to extract.
How to Install: Right Click this ZIP file and select "extract to Fortnite Config Editor v1.01/"
Now, run forceupdate.jar to get the latest update.

You can check the update log/redownload on:
secretlygod.github.io
sites.google.com/view/ericinc
Note: If it is 2019 you should go to the github website

How to use program:
1. Run Fortnite Config Editor.jar
2. Open your UserGameSettings.ini. It should be in c:/users/(yourname)/appdata/local/fortnitegame/saved/gameusersettings.ini
3. Copy down your old values and put them in the "old" values for the program. MAKE SURE THEY MATCH OR IT WILL NOT WORK
4. Put in your new values. NOTE: If you leave the values you aren't changing be, the program will still work
5. Select if you want mouse accerlation for Fortnite. It is on in Fortnite by default, but for competitve gameplay it is recommended to be turned off
6. Hit Confirm
7. Launch Fortnite and Enjoy!